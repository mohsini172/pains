<?php
define('DB_NAME', 'pains');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost');

//define('DB_NAME', 'utility');
//define('DB_USER', 'root');
//define('DB_PASSWORD', 'root');
//define('DB_HOST', 'localhost');


?>