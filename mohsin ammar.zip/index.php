<?php
include('auth/session.php');
header("Location: teacher")
?>